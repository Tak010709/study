package lang.string;

public class CharArrayMain {

	public static void main(String[] args) {
		char[] charArr = new char[] {'h','e','l','l','o'};
		String str1 = "hel";
		String str2 = "hello";
//		
//		System.out.println(charArr.length);
//		System.out.println(str.charAt(0));		
//		System.out.println(str2.substring(0));


		System.out.println(str1.concat(str2));
		System.out.println(str1.trim());
//		System.out.println(str2.indexOf("o"));
		
//		for(char c : charArr) {
//			
//		}
		

	}

}
