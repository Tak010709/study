package lang.object.toString;

public class ObjectPrinter {
	
	public static void print(Object obj) {
		String str = "객체정보 출력 -> " + obj.toString();
		
		System.out.println(str);
		
	}
}
