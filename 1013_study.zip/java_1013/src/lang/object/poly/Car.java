package lang.object.poly;

public class Car {
	
	private String carName;
	
	public void move() {
		System.out.println("붕붕");
	}
	
	public Car(String carName) {
		this.carName = carName;
	}
}
