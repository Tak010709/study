package lang.wrapper;

public class SystemMain {
	
	public static void main(String[] args) {
		// 현재 시간(밀리초)를 가져온다
		
		long currentTimeMillis = System.currentTimeMillis();
		System.out.println(currentTimeMillis);
		
		
	}
}
